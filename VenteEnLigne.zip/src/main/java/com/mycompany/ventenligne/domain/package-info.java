/**
 * JPA domain objects.
 */
package com.mycompany.ventenligne.domain;
