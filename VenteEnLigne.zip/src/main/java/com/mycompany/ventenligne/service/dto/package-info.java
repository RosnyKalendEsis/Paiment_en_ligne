/**
 * Data Transfer Objects.
 */
package com.mycompany.ventenligne.service.dto;
