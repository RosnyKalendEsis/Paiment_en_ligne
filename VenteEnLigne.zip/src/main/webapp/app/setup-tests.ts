import { loadIcons } from './config/icon-loader';

loadIcons();
