/**
 * Spring Security configuration.
 */
package com.mycompany.ventenligne.security;
