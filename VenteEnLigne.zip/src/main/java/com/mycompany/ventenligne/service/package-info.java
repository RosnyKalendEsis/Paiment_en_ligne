/**
 * Service layer beans.
 */
package com.mycompany.ventenligne.service;
