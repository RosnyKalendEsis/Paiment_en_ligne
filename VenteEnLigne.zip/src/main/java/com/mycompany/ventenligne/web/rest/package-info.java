/**
 * Spring MVC REST controllers.
 */
package com.mycompany.ventenligne.web.rest;
